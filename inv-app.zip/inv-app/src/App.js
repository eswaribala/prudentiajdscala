import logo from './logo.svg';
import './App.css';
import React from "react";
/*
function App() {
  return (
    <div className="App">
     <h2>John Deere Inventory App</h2>
    </div>
  );
}
*/
export class App extends React.Component{

    constructor(props, context) {
        super(props, context);
    }

    componentWillUnmount() {
        super.componentWillUnmount();
    }

    componentDidMount() {
        super.componentDidMount();
    }

    render() {
        return (
            <div className="App">
                <h2>John Deere Inventory App</h2>
            </div>
        );
    }
}

export default App;
